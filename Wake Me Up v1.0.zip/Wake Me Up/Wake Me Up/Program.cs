﻿using System;
using System.Drawing;
using System.Windows.Forms;
using static NativeMethods;

class Program
{
    static Timer inactivityTimer = new Timer();

    [STAThread]
    static void Main()
    {
        // Set the timer interval to check for inactivity (2 minutes)
        inactivityTimer.Interval = 90000; // 1.5 minutes in milliseconds
        inactivityTimer.Tick += CheckInactivity;
        inactivityTimer.Start();

        // Start a message loop to keep the application running
        Application.Run();
    }

    private static void CheckInactivity(object sender, EventArgs e)
    {
        // Check if the mouse has been inactive for more than 1.5 minutes
        if (Environment.TickCount - GetLastInputTime() > 90000)
        {
            // Move the mouse slightly by 5 pixels each way - to the bottom right corner. 
            NativeMethods.MoveMouse(5, 5);
        }
    }

    private static uint GetLastInputTime()
    {
        LASTINPUTINFO lii = new LASTINPUTINFO();
        lii.cbSize = (uint)System.Runtime.InteropServices.Marshal.SizeOf(lii);
        lii.dwTime = 0;

        //retrieves time when last action was made on a PC
        if (NativeMethods.GetLastInputInfo(ref lii))
        {
            return lii.dwTime;
        }

        return 0;
    }
}

class NativeMethods
{
    [System.Runtime.InteropServices.DllImport("user32.dll")]
    public static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);

    [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
    public struct LASTINPUTINFO
    {
        public uint cbSize;
        public uint dwTime;
    }
    /// <summary>
    /// This method moves cursor by x,y from the current position
    /// </summary>
    /// <param name="x">offset to move in x axe</param>
    /// <param name="y">offset to move in y axe</param>
    public static void MoveMouse(int x, int y)
    {
        Point currentPosition = Cursor.Position;
        Point newPosition = new Point(currentPosition.X + x, currentPosition.Y + y);
        Cursor.Position = newPosition;
    }
}